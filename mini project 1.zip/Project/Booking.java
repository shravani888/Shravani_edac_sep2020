package Project;

import java.util.Scanner;

class Booking
{
    String myString1;
    String myString;
    int number;
    String place;
    String myString12;
    String myString11;
    int otpNo;
    int count;
    public void Booking()
    {


        System.out.println("-----------------------------------");
        Scanner input = new Scanner(System.in);

        System.out.println("Enter your name ");
       // input.nextLine();
         myString1 = input.nextLine();

         System.out.println("Enter your OTP no");
         otpNo=input.nextInt();


        System.out.println("-----------------------------------");

        System.out.println("Enter car information ");
        System.out.println("-----------------------------------");
        System.out.println("Enter car name ");
        input.nextLine();
        myString = input.nextLine();

        System.out.print("Enter car range ");
        number = input.nextInt();
        // System.out.println("your car name is " + myString1);
        // System.out.println("your car name is " + myString);
        // System.out.println("You entered range is  " + number);
        System.out.println("-----------------------------------");
        if (number <= 200) {
            System.out.println("Hello " + myString1 + " your car name is  " + myString + " !!!");
            System.out.println("And your range is below 200 you need 2 hr to full charge");
        } else if (number <= 400) {
            System.out.println("Hello " + myString1 + "  your car name is  " + myString + " !!!");
            System.out.println("And your range is below 400 you need 4 hr to full charge");

        } else if (number <= 800) {
            System.out.println("Hello " + myString1 + "  your car name is  " + myString + " !!!");
            System.out.println("And your range is below 800 you need more than 5 hr to full charge");
        } else {
            System.out.println("Hello " + myString1 + "  your car name is  " + myString + " !!!");
            System.out.println("And you entered wrong number");
        }
        System.out.println("-----------------------------------");

        System.out.println("HOW MUCH HRS DO YOU HAVE????");
        int number1 = input.nextInt();
        if (number1 <= 1) {
            System.out.println(" you have very less time to charge your car");
        } else if (number1 <= 2) {
            System.out.println(" you have sufficient time to charge your car");
        } else
        {
            System.out.println(" you have sufficient time to charge your car");
        }
        System.out.println("_");

        System.out.println("Select your location 1.GOA 2.INDORE 3.NASHIK 4.MUMBAI");
        int num = input.nextInt();

        switch (num) {

            case 1:
                System.out.println("YOU SELECT 1.GOA");
                place="GOA";
                System.out.println("GREAT WE HAVE 4 CHARGING POINTS TO CHARGE YOUR CAR");

                break;
            case 2:
                System.out.println("YOU SELECT 2.INDORE");
                place="INDORE";
                System.out.println("GREAT WE HAVE  3 CHARGING POINTS TO CHARGE YOUR CAR");
                break;
            case 3:
                System.out.println("YOU SELECT 3.NASHIK");
                place="NASHIK";
                System.out.println("WE HAVE ONLY 2 CHARGING POINTS TO CHARGE YOUR CAR");
                break;
            case 4:
                System.out.println("YOU SELECT 4.MUMBAI");
                place="MUMBAI";
                System.out.println("GREAT WE HAVE 8 CHARGING POINTS TO CHARGE YOUR CAR");
                break;
            default:
                System.out.println("SELECT WRONG LOCATION " + num);
        }
        System.out.println("_");

        System.out.println("Enter date");
        Scanner input12 = new Scanner(System.in);
         myString12 = input12.next();


        System.out.println("Enter time");
        Scanner input11 = new Scanner(System.in);
        myString11 = input11.next();

        System.out.println("your entered date is " + myString12);
        System.out.println("your entered time is " + myString11);

        System.out.println("Do you want to Confirm your Booking \n To confirm (y/n)");
        char ch = input11.next().charAt(0);
        if (ch == 'y' || ch == 'Y')
        {
            System.out.println("enter paymet method, we charge 600 per hrs ");
            System.out.println("1.UPI 2.Debit card 3.Pay when Reach ");
            int num88 = input.nextInt();
            switch (num88) {
                case 1:
                    System.out.println("You choose UPI ");
                    System.out.println("your selected UPI " + number1 + " your charges is " + number1 * 600 + " Thank you ");
                    break;
                case 2:
                    System.out.println("You  choose Debit card ");
                    System.out.println("your selected Debit " + number1 + " your charges is " + number1 * 600 + " Thank you ");
                    break;
                case 3:
                    System.out.println("pay when reach ");
                    System.out.println("your selected reach " + number1 + " your charges is " + number1 * 600 + " Thank you ");
                    break;
                default:
                    System.out.println("choose wrong option try again ");
                    break;

            }
//
        }
        else
            {
            System.out.println("Booking is not confirmed");
           }



        // closing the scanner object
        //input.close();

    }




    public void displayPreviousBooking()
    {
        System.out.println("Name :" +myString1);
        System.out.println("OTP No :" +otpNo );
        System.out.println("Vehicle name :" +myString);
        System.out.println("car Range :" +number);
        System.out.println("location :" +place);
        System.out.println("Date :" +myString12);
        System.out.println("Time :" +myString11);
    }
}
