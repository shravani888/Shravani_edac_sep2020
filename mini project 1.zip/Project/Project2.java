package Project;
import java.io.InputStreamReader;
import java.util.Scanner;


public class Project2
{

    public static void main(String[] args)
    {
        Booking b[]=new Booking[100];
        Scanner sc=new Scanner(System.in);
        int i=0;
        char ch;
        if(i<=99)
        {
            do
                {
                System.out.println("Welcome to EDAC electric car charging reservation ");
                System.out.println("choose option \n 1.Booking for charging slots \n 2.cancellation of Booking \n 3.show Previous all bookings \n 4.Exit");


                int ch1 = sc.nextInt();
                switch (ch1)
                {
                    case 1:
                        System.out.println("Booking For Charging Slots");
                        b[i] = new Booking();     //creat array and store booking
                        b[i].Booking();
                        i++;
                        break;
                    case 2:
                        System.out.println("cancellation of Booking");
                        System.out.println("Enter your OTP :");
                        int otp= sc.nextInt();
                        int count=-1;
                        for(int j=0;j<i;j++)
                        {
                            if (b[j].otpNo ==otp)
                            {
                                count++;
                                break;
                            }
                            count++;
                        }
                        for(int j=count;j<i;j++)       
                        {
                           b[j]=b[j+1];
                        }
                        i--;
                        System.out.println("booking is cancel");
                        break;


                    case 3:
                        for(int j=0;j<i;j++)
                        {
                            b[j].displayPreviousBooking();    //to call display function
                        }
                        break;
                    case 4:
                        System.exit(0);
                        break;
                    default:
                        System.out.println("choose appropriate option");


                }
                System.out.println("Do you want to continue y/n");
                ch = sc.next().charAt(0);
            }

            while (ch == 'y' || ch == 'Y');

        }
        else
        {
            System.out.println("Booking list full");
        }

    }
}