package interface_assignment1;
class Student
{
	int rollNo;
	String name;
	void  setData(int rm,String nm)
	{
		rollNo=rm;
		name=nm;
	}
	void showData()
	{
		System.out.println(rollNo);
		System.out.println(name);
	}
}
public class StudentDemo {
	public static void main(String arg[])
	{
		Student obj=new Student();
		obj.setData(101,"Saurabh");
		obj.showData();
	}

}
