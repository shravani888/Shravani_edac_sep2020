package interface_assignment1;

import java.util.Scanner;

class Circle
{
	double radius;
	double area;
	void init()
	
	{
		Scanner sc =new Scanner(System.in);
		radius=sc.nextDouble();
	}
	void calculateArea()
	{
		area=3.14*radius*radius;
	}
	void display()
	{
		System.out.println(radius);
		System.out.println(area);
	}
	}

public class CircleDemo {
	public static void main(String args[])
	{
		Circle cir=new Circle();
		cir.init();
		cir.calculateArea();
		cir.display();
	}

}
