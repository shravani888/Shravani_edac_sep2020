package interface_assignment1;
import java.util.*;
class MathOperation
{
	public static int add(int a,int b)
	{
		return(a+b);
	}
	public static int subtract(int a,int b)
	{
		return(a-b);
	}
	public static int multiply(int a,int b)
	{
		return(a*b);
	}
	public static int power(int a,int b)
	{
		b=a*a;
		return(b);
	}
	}

public class Demo {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		int j=sc.nextInt();
		System.out.println(MathOperation.add(i,j));	
		System.out.println(MathOperation.subtract(i,j));	
		System.out.println(MathOperation.multiply(i,j));	
		System.out.println(MathOperation.power(i,j));	
	}
}

