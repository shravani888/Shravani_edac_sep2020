package interface_assignment1;

public class Demo1 {

}
