package interface_assignment1;

import java.util.Scanner;
class Employee1 
{
	int empNo;
	double salary;
	double totalSalary;
	public Employee1(double salary) 
	{
		this.salary = salary;
		empNo++;
		totalSalary=12*salary;
	}
	void display()
	{
		System.out.println("EMPLOYEE : "+empNo);
		System.out.println("EMPLOYEE TOTAL SALARY : "+totalSalary);
	}
	
}
public class EmployeeDemo 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Employee1[] e = new Employee1[5];
		for(int i = 0 ; i < 5 ; i++)
		{
			
			e[i] = new Employee1(sc.nextDouble());
			e[i].display();
		}
		sc.close();
	}
}