package interface_assignment1;
import java.util.Scanner;
public class MathOperation1 {
	int multiply(int a,int b)
	{ 
		return(a*b);
	}
	float multiply(float a,float b,float c)
	{
		return(a*b*c);
	}
	int multiply(int arr[])
	{int mult=1;
		for(int x:arr)
		{
			mult*=x;
		}
		return mult;
	}
	double multiply(double x ,int y)
	{
		return(x*y);
	}


	public static void main(String args[])
	{
		MathOperation1 obj=new MathOperation1();
		System.out.println(obj.multiply(10, 20));
		System.out.println(obj.multiply(10.0f, 20.0f,30.0f));
		int c[]={10,20,30,40,50};
		System.out.println(obj.multiply(c));
		System.out.println(obj.multiply(10.035,3));
	}
	}
